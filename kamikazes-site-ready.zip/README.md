# Kamikaze's House of Rock Website

This is a mobile-friendly React + Tailwind website for **Kamikaze's**, a bar and nightclub located at:

**2408 Adams Ave, Ogden, UT 84404**

### 🚀 Features

- 🎸 Live music every weekend
- 🎤 Karaoke most nights
- 🎙️ Open mic nights on Thursdays
- 📧 Contact & booking via kamikazesogden@yahoo.com

### 🛠️ Development

To run the site locally:

```bash
npm install
npm run dev
```

Visit `http://localhost:5173` in your browser.

---

Built with ❤️ using React, TailwindCSS, and Vite.
